import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserDetailsService } from '../user-details.service';
import { UserPosts } from '../model/userModel';
@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.css']
})
export class PostListComponent implements OnInit {

  userPosts:UserPosts[]=[];
  constructor( private route: ActivatedRoute,
    private userDetailsService:UserDetailsService,
    private router:Router) { }

  ngOnInit() {
    this.getPostDetails(this.route.snapshot.paramMap.get('id'));
  }

  getPostDetails(id){
     this.userDetailsService.getUsersPost(id).subscribe((data:UserPosts[])=>{
      this.userPosts=data;     })
  }

}
