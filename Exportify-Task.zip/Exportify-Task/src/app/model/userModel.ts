export interface UserData{
    id?:number,
    name?:string,
    email?:string,
    phone?:string,
    website?:string
}

export interface UserPosts{
    id?:number,
    body?:string,
    title?:string,
}