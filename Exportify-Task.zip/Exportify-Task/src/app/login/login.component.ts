import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import CryptoJS from 'crypto-js';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  fieldTextType: boolean=false;

  constructor(private fb: FormBuilder,
    private router:Router
    ) {}
  ngOnInit() {
    this.initRegForm();
  }

  initRegForm() {
    this.loginForm = this.fb.group({
      username: ["", Validators.required],
      password: ["", [  Validators.required ,Validators.minLength(5)]],
    });
  }

  toggleFieldTextType() {
    console.log(this.fieldTextType)
    this.fieldTextType = !this.fieldTextType;
  }

  onLogin(value){
    if (this.loginForm.invalid) {
      console.log(this.loginForm)
      this.loginForm.markAllAsTouched()
      console.log(this.loginForm)
  }else{
    var hash= CryptoJS.SHA1(value.password);
    value.password=hash.toString()
     localStorage.setItem('userInfo',JSON.stringify(value))
     this.router.navigateByUrl('/userDetails')
  }
    
  }
}
