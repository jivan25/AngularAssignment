import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserData } from '../model/userModel';
import { UserDetailsService } from '../user-details.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  listOfUserDetails:UserData[]=[];
  listOfUserDetailsForSearch:UserData[]=[];
  constructor(private userDetailsService:UserDetailsService,
    private router:Router
    ) { }

  ngOnInit() {
    this.getUserData()
  }

  getUserData(){
    this.userDetailsService.getUserDetails().subscribe((data:UserData[])=>{
      this.listOfUserDetails=data
      this.listOfUserDetailsForSearch=data
    })
  }

  search(event){
    this.listOfUserDetails= this.listOfUserDetailsForSearch.filter((user)=>{
      return user.name.toLowerCase().includes(event.toLowerCase())
    })
  }

  onPostClick(id:number){
    this.router.navigateByUrl('/post/'+id)
  }

}
