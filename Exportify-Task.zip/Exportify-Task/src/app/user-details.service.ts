import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  GET_USER_DETAILS_URL=environment.baseUrl+'users'
  GET_USER_POSTS_URL=environment.baseUrl+'posts?userId='
  constructor(private httpClient:HttpClient) { 
  }


  getUserDetails(){
    return this.httpClient.get(this.GET_USER_DETAILS_URL).pipe(catchError(this.handleError1))
  }

  getUsersPost(id){
    return this.httpClient.get(this.GET_USER_POSTS_URL+id).pipe(catchError(this.handleError1))
  }
  
    private handleError1(error: HttpErrorResponse) {
      return throwError(
        'There is a problem with the service. Please make sure server is running');
    }
  
}
